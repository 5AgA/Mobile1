package dduw.com.mobile.finalreport

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import dduw.com.mobile.finalreport.databinding.ActivityIntroBinding

class IntroActivity : AppCompatActivity() {
    val introBinding by lazy {
        ActivityIntroBinding.inflate(layoutInflater)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(introBinding.root)
        title = "개발자 정보"

        introBinding.goBlog.setOnClickListener {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://e-dl.tistory.com/"))
            startActivity(intent)
        }
        introBinding.goGithub.setOnClickListener {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/5AgA"))
            startActivity(intent)
        }
    }
}
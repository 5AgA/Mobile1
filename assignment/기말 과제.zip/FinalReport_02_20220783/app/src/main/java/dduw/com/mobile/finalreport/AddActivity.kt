package dduw.com.mobile.finalreport

import android.content.ContentValues
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import dduw.com.mobile.finalreport.databinding.ActivityAddBinding
import dduw.com.mobile.finalreport.sampledata.AniDBHelper
import dduw.com.mobile.finalreport.sampledata.AniDto

class AddActivity : AppCompatActivity() {

    val addBinding by lazy {
        ActivityAddBinding.inflate(layoutInflater)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(addBinding.root)
        title = "애니메이션 추가"

        addBinding.etAddPoster.setImageResource(R.mipmap.sample)

        addBinding.btnAddAni.setOnClickListener {
            if (addBinding.etAddTitle.text.toString() == ""
                || addBinding.etAddYear.text.toString() == ""
                || addBinding.etAddEp.text.toString() == ""
                || addBinding.etAddCharacters.text.toString() == ""
                || addBinding.etAddGenre.text.toString() == "") {
                Toast.makeText(this, "빈칸이 존재합니다", Toast.LENGTH_SHORT).show()
            } else {
                val title = addBinding.etAddTitle.text.toString()
                val genre = addBinding.etAddGenre.text.toString()
                val year = addBinding.etAddYear.text.toString()
                val ep = addBinding.etAddEp.text.toString()
                val characters = addBinding.etAddCharacters.text.toString()

                if (addAni(AniDto(0, R.mipmap.sample, title, year, ep, characters, genre)) > 4) {
                    setResult(RESULT_OK)
                } else {
                    setResult(RESULT_CANCELED)
                }
                finish()
            }
        }

        addBinding.btnAddCancel.setOnClickListener {
            finish()
        }
    }

    fun addAni (newDto: AniDto) : Long {
        val helper = AniDBHelper(this)
        val db = helper.writableDatabase

        val newRow = ContentValues()
        newRow.put("poster", newDto.poster)
        newRow.put("title", newDto.title)
        newRow.put("genre", newDto.genre)
        newRow.put("year", newDto.year)
        newRow.put("ep", newDto.ep)
        newRow.put("characters", newDto.characters)
        val newCount = db.insert("ani_table", null, newRow)

        helper.close()

        return newCount
    }
}
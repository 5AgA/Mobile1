package dduw.com.mobile.finalreport.sampledata

import java.io.Serializable

data class AniDto (val id: Long, val poster: Int, var title: String, var year: String,
                   var ep: String, var characters: String, var genre: String) : Serializable{

    override fun toString() = "$title"
}
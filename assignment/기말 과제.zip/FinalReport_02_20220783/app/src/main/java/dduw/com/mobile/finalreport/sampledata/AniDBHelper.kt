package dduw.com.mobile.finalreport.sampledata

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.provider.BaseColumns
import dduw.com.mobile.finalreport.R

class AniDBHelper (context: Context?) : SQLiteOpenHelper(context, DB_NAME, null, 1) {

    companion object {
        const val DB_NAME = "ani_db"
        const val TABLE_NAME = "ani_table"
        const val COL_POSTER = "poster"
        const val COL_TITLE = "title"
        const val COL_GENRE = "genre"
        const val COL_YEAR = "year"
        const val COL_EP = "ep"
        const val COL_CHARACTERS = "characters"
    }

    override fun onCreate(db: SQLiteDatabase?) {
        val CREATE_TABLE =
            "CREATE TABLE $TABLE_NAME ( ${BaseColumns._ID} INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "$COL_POSTER TEXT, $COL_TITLE TEXT, $COL_YEAR TEXT, $COL_EP TEXT, " +
                    "$COL_CHARACTERS TEXT, $COL_GENRE TEXT)"
        db?.execSQL(CREATE_TABLE)

        db?.execSQL("INSERT INTO $TABLE_NAME VALUES (NULL, " + R.mipmap.jujutsukaisen +
                ", '주술회전 1기', '2020 ~ 2021', '24', '이타도리 유지, 후시구로 메구미, 고죠 사토루, 쿠기사키 노바라'," +
                "'능력자 배틀')")
        db?.execSQL("INSERT INTO $TABLE_NAME VALUES (NULL, " + R.mipmap.demonslayer +
                ", '귀멸의 칼날 1기', '2019', '26', '카마도 탄지로, 카마도 네즈코, 아가츠마 젠이츠, 하시비라 이노스케'," +
                "'시대극 판타지, 액션')")
        db?.execSQL("INSERT INTO $TABLE_NAME VALUES (NULL, " + R.mipmap.neverland +
                ", '약속의 네버랜드 2기', '2021', '11', '엠마, 노먼, 레이, 돈, 길다, 코니, 필, 안나'," +
                "'스릴러, 다크 판타지, 액션')")
        db?.execSQL("INSERT INTO $TABLE_NAME VALUES (NULL, " + R.mipmap.onepunchman +
                ", '원펀맨 2기', '2019', '18', '사이타마, 제노스'," +
                "'액션, 히어로, 개그')")
        db?.execSQL("INSERT INTO $TABLE_NAME VALUES (NULL, " + R.mipmap.saiki +
                ", '사이키 쿠스오의 재난 2기', '2018', '24', '사이키 쿠스오, 넨도 리키, 카이도 슌, 하이로 키네시'," +
                "'개그, 학원, 초능력')")
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        val DROP_TABLE = "DROP TABLE IF EXISTS $TABLE_NAME"
        db?.execSQL(DROP_TABLE)
        onCreate(db)
    }
}
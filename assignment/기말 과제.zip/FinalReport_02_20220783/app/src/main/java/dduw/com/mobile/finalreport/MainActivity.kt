// 과제명: 애니 정보 관리 앱
// 분반: 02분반
// 학번: 20220783 성명: 오은아
// 제출일: 2024년 월 일
package dduw.com.mobile.finalreport

import android.annotation.SuppressLint
import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager.HORIZONTAL
import androidx.recyclerview.widget.RecyclerView
import dduw.com.mobile.finalreport.databinding.ActivityMainBinding
import dduw.com.mobile.finalreport.sampledata.AniAdapter
import dduw.com.mobile.finalreport.sampledata.AniDao
import dduw.com.mobile.finalreport.sampledata.AniDto

@Suppress("DEPRECATED_IDENTITY_EQUALS")
class MainActivity : AppCompatActivity() {

    val binding by lazy {
        ActivityMainBinding.inflate(layoutInflater)
    }
    val aniDao by lazy {
        AniDao(this)
    }

    lateinit var aniList : ArrayList<AniDto>

    val REQ_ADD = 100
    val REQ_UPDATE = 200

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        title = "애니메이션 목록"

        aniList = aniDao.getAll()
        val adapter = AniAdapter(aniList)
        binding.rvList.adapter = adapter
        binding.rvList.layoutManager = LinearLayoutManager(this).apply {
            orientation = HORIZONTAL
        }
        binding.rvList.setMagneticMove()

        // 수정
        adapter.setOnItemClickListener (object: AniAdapter.OnItemClickListener {
            override fun onItemClick(view: View, position: Int) {
                val intent = Intent(this@MainActivity, UpdateActivity::class.java)
                intent.putExtra("dto", aniList.get(position))
                startActivityForResult(intent, REQ_UPDATE)
            }
        })

        // 삭제
        adapter.setOnItemLongClickListener (object : AniAdapter.OnItemLongClickListener {
            override fun onItemLongClick (view: View, position: Int) : Boolean {
                val builder = AlertDialog.Builder(this@MainActivity).apply {
                    setTitle("애니메이션 삭제")
                    setMessage(aniList[position].title + " 애니메이션을 정말 삭제하시겠습니까?")
                    setPositiveButton("네") { dialogInterface: DialogInterface?, i: Int ->
                        notifyDB(aniDao.deleteAni(aniList[position]), false)
                    }
                    setNegativeButton("아니오", null)
                }
                builder.show()
                return true
            }
        })

    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId) {
            // 추가
            R.id.optAdd -> {
                val intent = Intent(this, AddActivity::class.java)
                startActivityForResult(intent, REQ_ADD)
            }
            // 종료
            R.id.optExit -> {
                val builder = AlertDialog.Builder(this).apply {
                    setTitle("종료")
                    setMessage("정말 종료하시겠습니까?")
                    setPositiveButton("네") { dialogInterface: DialogInterface?, i: Int ->
                        finish()
                    }
                    setNegativeButton("아니오", null)
                }
                builder.show()
            }
            // 자기소개
            R.id.optIntro -> {
                val intent = Intent(this, IntroActivity::class.java)
                startActivity(intent)
            }
        }
        return super.onOptionsItemSelected(item)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQ_UPDATE, REQ_ADD -> {
                notifyDB(resultCode, true)
            }
        }
    }

    @SuppressLint("NotifyDataSetChanged")
    fun notifyDB (result: Int, isReq: Boolean) {
        if (isReq) {
            if (result == AppCompatActivity.RESULT_OK) {
                aniList.clear()
                aniList.addAll(aniDao.getAll())
                binding.rvList.adapter?.notifyDataSetChanged()
            }
        } else {
            if (result > 0) {
                aniList.clear()
                aniList.addAll(aniDao.getAll())
                binding.rvList.adapter?.notifyDataSetChanged()
            }
        }
    }

    // 스크롤을 위해 구글링한 코드
    fun RecyclerView.getScrollDistanceOfColumnClosestToLeft(): Int {
        val manager = layoutManager as LinearLayoutManager?
        val firstVisibleColumnViewHolder = findViewHolderForAdapterPosition(
            manager!!.findFirstVisibleItemPosition()
        ) ?: return 0
        val columnWidth = firstVisibleColumnViewHolder.itemView.measuredWidth
        val left = firstVisibleColumnViewHolder.itemView.left
        val absoluteLeft = Math.abs(left)

        return if (absoluteLeft <= columnWidth / 2) left else columnWidth - absoluteLeft
    }

    fun RecyclerView.setMagneticMove(nStart : Int = 0 ){
        addOnScrollListener(object: RecyclerView.OnScrollListener(){
            var oldMoveTo : Int = 0
            override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
                val moveTo = getScrollDistanceOfColumnClosestToLeft() - nStart
                if(newState == RecyclerView.SCROLL_STATE_IDLE){
                    if(moveTo !== oldMoveTo){
                        recyclerView.smoothScrollBy(moveTo, 0)
                        oldMoveTo = moveTo
                    }
                }
            }
        })
    }
}
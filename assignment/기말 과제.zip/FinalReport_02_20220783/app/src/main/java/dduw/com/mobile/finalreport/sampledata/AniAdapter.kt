package dduw.com.mobile.finalreport.sampledata

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import dduw.com.mobile.finalreport.databinding.ListItemBinding

class AniAdapter (val aniList: ArrayList<AniDto>)
    : RecyclerView.Adapter<AniAdapter.AniViewHolder>() {

    override fun getItemCount() = aniList.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AniViewHolder {
        val itemBinding= ListItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return AniViewHolder(itemBinding)
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: AniViewHolder, position: Int) {
        holder.itemBinding.ivPoster.setImageResource( aniList[position].poster )
        holder.itemBinding.ivTitle.text = aniList[position].title
        holder.itemBinding.ivYear.text = aniList[position].year + "년"
        holder.itemBinding.ivEp.text = aniList[position].ep + "부작"
        holder.itemBinding.ivGenre.text = aniList[position].genre
    }

    inner class AniViewHolder (val itemBinding: ListItemBinding) : RecyclerView.ViewHolder(itemBinding.root) {
        init {
            itemBinding.root.setOnClickListener {
                clickListener?.onItemClick(it, adapterPosition)
            }
            itemBinding.root.setOnLongClickListener {
                longClickListener?.onItemLongClick(it, adapterPosition)
                true
            }
        }
    }

    var clickListener : OnItemClickListener? = null
    var longClickListener : OnItemLongClickListener? = null

    interface OnItemClickListener {
        fun onItemClick (view: View, position: Int)
    }
    interface OnItemLongClickListener {
        fun onItemLongClick (view: View, position: Int) : Boolean
    }

    fun setOnItemClickListener (listener: OnItemClickListener?) {
        this.clickListener = listener
    }
    fun setOnItemLongClickListener (listener: OnItemLongClickListener?) {
        this.longClickListener = listener
    }
}
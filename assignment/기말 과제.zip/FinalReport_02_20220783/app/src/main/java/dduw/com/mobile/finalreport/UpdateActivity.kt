package dduw.com.mobile.finalreport

import android.content.ContentValues
import android.content.DialogInterface
import android.os.Bundle
import android.provider.BaseColumns
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import dduw.com.mobile.finalreport.databinding.ActivityUpdateBinding
import dduw.com.mobile.finalreport.sampledata.AniDBHelper
import dduw.com.mobile.finalreport.sampledata.AniDto

class UpdateActivity : AppCompatActivity() {
    val updateBinding by lazy {
        ActivityUpdateBinding.inflate(layoutInflater)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(updateBinding.root)
        title = "애니메이션 수정"

        val dto = intent.getSerializableExtra("dto") as AniDto

        updateBinding.etUpdatePoster.setImageResource(dto.poster)
        updateBinding.etUpdateTitle.setText(dto.title)
        updateBinding.etUpdateYear.setText(dto.year)
        updateBinding.etUpdateEp.setText(dto.ep)
        updateBinding.etUpdateCharacters.setText(dto.characters)
        updateBinding.etUpdateGenre.setText(dto.genre)

        updateBinding.btnUpdateAni.setOnClickListener {
            if (updateBinding.etUpdateTitle.text.toString() == ""
                || updateBinding.etUpdateYear.text.toString() == ""
                || updateBinding.etUpdateEp.text.toString() == ""
                || updateBinding.etUpdateCharacters.text.toString() == ""
                || updateBinding.etUpdateGenre.text.toString() == "") {
                Toast.makeText(this, "빈칸이 존재합니다", Toast.LENGTH_SHORT).show()
            } else {
                dto.title = updateBinding.etUpdateTitle.text.toString()
                dto.year = updateBinding.etUpdateYear.text.toString()
                dto.ep = updateBinding.etUpdateEp.text.toString()
                dto.characters = updateBinding.etUpdateCharacters.text.toString()
                dto.genre = updateBinding.etUpdateGenre.text.toString()

                if (updateAni(dto) > 0) {
                    setResult(RESULT_OK)
                } else {
                    setResult(RESULT_CANCELED)
                }

                finish()
            }
        }

        updateBinding.btnUpdateCancel.setOnClickListener {
            setResult(RESULT_CANCELED)
            finish()
        }
    }

    fun updateAni (dto: AniDto) : Int{
        val helper = AniDBHelper(this)
        val db = helper.writableDatabase

        val updateVal = ContentValues()
        updateVal.put(AniDBHelper.COL_TITLE, dto.title)
        updateVal.put(AniDBHelper.COL_YEAR, dto.year)
        updateVal.put(AniDBHelper.COL_EP, dto.ep)
        updateVal.put(AniDBHelper.COL_CHARACTERS, dto.characters)
        updateVal.put(AniDBHelper.COL_GENRE, dto.genre)
        val whereClause = "${BaseColumns._ID}=?"
        val whereArgs = arrayOf(dto.id.toString())

        val resultCount = db.update(
            AniDBHelper.TABLE_NAME,
            updateVal, whereClause, whereArgs)

        helper.close()
        return resultCount
    }
}
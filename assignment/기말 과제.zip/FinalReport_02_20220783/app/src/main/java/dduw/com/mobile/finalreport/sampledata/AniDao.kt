package dduw.com.mobile.finalreport.sampledata

import android.annotation.SuppressLint
import android.content.Context
import android.provider.BaseColumns

class AniDao (val context: Context) {

    @SuppressLint("Range", "Recycle")
    fun getAll() : ArrayList<AniDto> {
        val helper = AniDBHelper(context)
        val db = helper.readableDatabase
        val cursor = db.query(AniDBHelper.TABLE_NAME, null, null, null, null, null, null)

        val aniList = arrayListOf<AniDto>()
        with (cursor) {
            while (moveToNext()) {
                val id = getLong( getColumnIndex(BaseColumns._ID) )
                val poster = getInt(getColumnIndex(AniDBHelper.COL_POSTER))
                val title = getString(getColumnIndex(AniDBHelper.COL_TITLE))
                val year = getString(getColumnIndex(AniDBHelper.COL_YEAR))
                val ep = getString(getColumnIndex(AniDBHelper.COL_EP))
                val characters = getString(getColumnIndex(AniDBHelper.COL_CHARACTERS))
                val genre = getString(getColumnIndex(AniDBHelper.COL_GENRE))
                val dto = AniDto(id, poster, title, year, ep, characters, genre)
                aniList.add(dto)
            }
        }
        return aniList
    }

    fun deleteAni(dto: AniDto) : Int {
        val helper = AniDBHelper(context)
        val db = helper.writableDatabase

        val whereClause = "${BaseColumns._ID}=?"
        val whereArgs = arrayOf(dto.id.toString())

        val deleteCount = db.delete(AniDBHelper.TABLE_NAME, whereClause, whereArgs)

        return deleteCount
    }
}
package ddwu.com.mobile.fooddbexam02.data

class FoodDao {

}